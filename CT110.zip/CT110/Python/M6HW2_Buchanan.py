total=0
while True:
    testScore = int(input('enter grade: '))
    if testScore < 0:
        break
    total += testScore
    print('Your total is: ', total)
   
        
    

