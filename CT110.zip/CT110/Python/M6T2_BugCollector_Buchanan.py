# CTI-110 
# M5HW1 - Bug Collector 
# Markelvus Buchanan
# 29 November 2017
#

totalDays = 7
totalAmountOfBugs = 0

for currentDay in range(1, totalDays + 1):
    bugsCollected = int(input('Number of bugs collected that day' + str(currentDay) + ': '))
    totalAmountOfBugs += bugsCollected
    
print()
print('Total amount of bugs collected for each', totalDays, 'days are', totalAmountOfBugs)
