# This program will convert your grade to it's corresponding letter value, and give your average.
# 6 December 2017
# CTI-110 M7HW1 - Test Average and Grade
# Markelvus Buchanan

def calcAverage(test1, test2, test3, test4, test5, test6, test7, test8):
    average = (test1 + test2 + test3 + test4 + test5 + test6 + test7 + test8) / 8
    return average
def yourGrade(testGrade):
    if(testGrade >= 90):
        return 'A'
    elif(testGrade > 80 and testGrade < 90):
        return 'B'
    elif(testGrade > 70 and testGrade < 80):
        return 'C'
    elif(testGrade > 60 and testGrade < 70):
        return 'D'
    else:
        return 'F'
def askForGrade():
   test1 = float(input('Enter test 1: '))
   test2 = float(input('Enter test 2: '))
   test3 = float(input('Enter test 3: '))
   test4 = float(input('Enter test 4: '))
   test5 = float(input('Enter test 5: '))
   test6 = float(input('Enter test 6: '))
   test7 = float(input('Enter test 7: '))
   test8 = float(input('Enter test 8: '))
   return test1, test2, test3, test4, test5, test6, test7, test8

def printTableOfGrades(test1, test2, test3, test4, test5, test6, test7, test8):
    print('Test\t\tGrade')
    print(str(test1) + '\t\t' + yourGrade(test1), \
          str(test2) + '\t\t' + yourGrade(test2), \
          str(test3) + '\t\t' + yourGrade(test3), \
          str(test4) + '\t\t' + yourGrade(test4), \
          str(test5) + '\t\t' + yourGrade(test5), \
          str(test6) + '\t\t' + yourGrade(test6), \
          str(test7) + '\t\t' + yourGrade(test7), \
          str(test8) + '\t\t' + yourGrade(test8), sep = '\n')

def main():
    test1, test2, test3, test4, test5, test6, test7, test8 = askForGrade()
    printTableOfGrades(test1, test2, test3, test4, test5, test6, test7, test8)
    print( "Your average is: ", calcAverage( test1, test2, test3, test4,\
                                           test5, test6, test7, test8 ) )

    
main()
    
