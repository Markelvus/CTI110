import turtle
import random

wn = turtle.Screen()
t = turtle.Turtle()
wn.bgcolor("white")

colours = ["cyan", "purple", "red", "blue"]

t.penup()
t.forward(90)
t.left(45)
t.pendown()

def branch():
    for i in range(3):
        for i in range(3):
            t.forward(30)
            t.backward(30)
            t.right(45)
        t.left(90)
        t.backward(30)
        t.left(45)
    t.right(90)
    t.forward(90)

for i in range(16):
    branch()
    t.left(45)
    
    t.color(random.choice(colours))

wn.exitonclick()
