# CTI-110 
# M5HW1 - Distance Traveled
# Markelvus Buchanan
# 29 November 2017
#

timeElapsed = int(input('How many hours traveled?: '))
vehicleMph = float(input('Speed the vehicle is going: '))

print()

print('Hour', '\tDistance Traveled')

for currentHour in range(1, timeElapsed + 1):
    distanceTraveled = vehicleMph * currentHour
    print(currentHour, '\t', distanceTraveled)
