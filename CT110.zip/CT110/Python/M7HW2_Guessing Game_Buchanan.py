# This program will convert your grade to it's corresponding letter value, and give your average.
# 6 December 2017
# CTI-110 M7HW2 - Random Number Guessing Game
# Markelvus Buchanan

import random

randomNumber = random.randrange(0,50)
print("Hello, My name is Markelvus. I would like for you to guess a number between 0-50")
guessed = False

while guessed==False:
    userInput = int(input("Your best guess: "))
    if userInput==randomNumber:
        guessed = True
        print("Congrats!!! You win!")
    elif userInput>50:
        print("The guess range is from 0-50, choose a lower number")
    elif userInput<0:
        print("Our guess range is from 0-50, choose a higher number")
    elif userInput>randomNumber:
        print("Too High!! Try again")
    elif userInput < randomNumber:
        print("Too Low!! Try again")

print("Thanks for playing")


                      
    
    
