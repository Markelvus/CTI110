import turtle           
win = turtle.Screen()      
t = turtle.Turtle() 

for i in [0,1,2,3]:
    t.forward(50)          
    t.left(90)    
t.penup()
t.forward(200)
t.pendown()

for i in[0,1,2]:
    t.forward(100)
    t.left(120)




win.mainloop()             
