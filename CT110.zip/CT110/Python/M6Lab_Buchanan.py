# CTI-110 
# M6Lab
# Markelvus Buchanan
# 29 November 2017
#
import turtle
import random
t = turtle
t.pen(pencolor="purple", pensize=4)
colours = ["black", "purple"]

for j in range(8):
    for i in range(8):
        t.forward(60)
        t.left(45)
    t.left(45)

    t.color(random.choice(colours))

         
