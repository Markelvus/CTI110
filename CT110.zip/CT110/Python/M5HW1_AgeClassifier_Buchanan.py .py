# CTI-110 
# M5HW1 - Age Classifier 
# Markelvus Buchanan
# 23 November 2017
#

yourAge = int(input('enter age here: '))
if yourAge <= 1:
    print('infant')
elif yourAge < 13:
    print('child')
elif yourAge < 20:
    print('teenager')
elif yourAge >= 20:
    print('adult')
    
