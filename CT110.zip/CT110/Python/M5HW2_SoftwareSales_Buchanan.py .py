# CTI-110 
# M5HW1 - Age Classifier 
# Markelvus Buchanan
# 23 November 2017
#
yourPackageAmount = int(input('enter packages purchased:'))
priceOfPackage = 99
if yourPackageAmount < 10:
    discount = 0
elif yourPackageAmount < 20:
    discount = .10
elif yourPackageAmount < 50:
    discount = .20
elif yourPackageAmount < 100:
    discount = .30
else:
    discount = .40
    
subTotalPrice = yourPackageAmount * priceOfPackage
discountTotal = discount * subTotalPrice
total = subTotalPrice - discountTotal

print('discount amount : $' + format(discountTotal, ',.2f') + \
       '\nTotal price: $' + format(total, ',.2f'))
