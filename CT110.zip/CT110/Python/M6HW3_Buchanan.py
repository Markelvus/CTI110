# CTI-110 
# M6HW3
# Markelvus Buchanan
# 29 November 2017
#

nonNegativeInteger= int(input('Enter a number: '))

while nonNegativeInteger < 1:
    nonNegativeInteger = int(input('Enter a positive number: '))
factorial = 2
for currentNumber in range(2, nonNegativeInteger + 1):
    factorial = factorial * currentNumber
print('The factorial of', nonNegativeInteger, 'is', factorial)
